---
sidebar_position: 1
slug: /
---

# Juka documentation

Juka is a portable, easy-to-learn programming language. The same program runs on
desktop, mobile, the browser and the cloud, with no installer and no admin
rights required.

This page is the map. Pick the task you are doing; each section links to the
shortest path to it.

## Start here

| If you want to… | Read |
|---|---|
| Write and run your first program | **[Quickstart: your first Juka program](/docs/quickstart)** |
| Install Juka on Windows, macOS or Linux | [Install Juka](/docs/install) |
| Use Juka on Android or Windows as an app | [Apps](/docs/appinstall) |
| Run Juka in a browser tab | [Online IDE](https://ide.jukalang.com/) · [Juka in the browser](/docs/online) |
| Come from Python | [Language fundamentals](/docs/fundamentals) |

## Browse by task

### Get set up

- [Quickstart](/docs/quickstart) — zero to a running program in ten minutes.
- [Install the console build](/docs/install) — Windows, macOS, Linux and
  FreeBSD.
- [Install on Android or Windows](/docs/appinstall) — the app builds.
- [Run Juka offline](/docs/offline) — keep a copy on a thumb drive.
- [Jupyter kernel](/docs/n2_install/jupyter) — Juka cells in Notebook and Lab.
- [Unity package](/docs/n2_install/unity) and [.NET DLL](/docs/n2_install/dll).

### Learn the language

- [Fundamentals](/docs/fundamentals) — expressions, statements and functions.
- [Hello World](/docs/hello-world) — your first file.
- [Variables](/docs/variables) · [Strings](/docs/strings) · [Conditions](/docs/conditions) · [Classes](/docs/classes).
- [Examples](/examples) — short runnable programs, including parallel
  subroutines.

### Build and ship

- [JukaAPI](/docs/n5_online/api) — run Juka from another service over HTTP.
- [Online and WebAssembly](/docs/online) — run Juka in a browser or on a server.
- [Azure Functions](/docs/n2_install/azure-function) — a serverless host.
- [JukaOS](https://os.jukalang.com/) and the [GUI builder](https://generate.jukalang.com).

### Project and reference

- [Architecture](/docs/Contributing%20to%20Juka%20Project/architecture) — how the
  compiler is put together.
- [Visitor pattern](/docs/Contributing%20to%20Juka%20Project/visitorpattern) —
  the parser/compiler pattern used in the codebase.
- [Contributing guide](/docs/Contributing%20to%20Juka%20Project/introdev) —
  report a bug, write docs, or send a pull request.
- [Site mirrors](/docs/Other%20Content/sitemirrors) — alternate hosts if the
  main site is unreachable.

## Get help

- [FAQ](/docs/Other%20Content/faqs).
- [Troubleshooting on macOS](/docs/Other%20Content/troubleshooting-mac).
- [Discord](https://discord.gg/MsKWsErzfp) — the fastest place to ask.
- [GitHub issues](https://github.com/jukaLang/JukaHubV2/issues) — bug reports
  and feature requests.

## Platforms

Juka builds for Windows (x86, x64, ARM64), Linux (x86, x64, ARM, ARM64), macOS,
FreeBSD, Android, the browser through WebAssembly, AndroidTV, Azure Functions,
Docker and Jupyter. See [Install Juka](/docs/install) for the current download
list, and the [changelog](/changelog) for version notes.

## Contributing

The compiler, this website and the packages are open source. Start with the
[contributing guide](/docs/Contributing%20to%20Juka%20Project/introdev), then
look at the [community page](/community) for Discord and issue links.
