---
sidebar_position: 2
slug: /offline
---

# Offline Documentation

**There are two ways to access Juka documentation offline:**

* **Print to PDF:** Every page prints cleanly from the browser (Ctrl+P, or File → Print on macOS). Choose "Save as PDF" to keep a copy of any guide.
* **Cached Juka website (Juka PWA):** You can also create a cached version of the Juka website that can be accessed offline. To do this, follow these steps:

    1. On a mobile device, click on the "add this to homepage" button. This will automatically create a PWA app that can be accessed even without the internet.
    2. On a desktop computer, find the browser URL field and look at the right section. Click on the "Install Juka Programming Language Website" button. This will install a browser app that can be ran offline (without internet).

Once you have created a cached version of the Juka website, you can access it offline by opening the PWA app or the browser app.
