---
sidebar_position: 0
slug: /quickstart
---

# Quickstart: your first Juka program

This page takes you from nothing to a running program in about ten minutes.
Pick the browser if you just want to see the language; pick the portable build
if you want Juka on your machine.

## 1. Choose how to run Juka

### In the browser (no install)

Open the [Juka online IDE](https://ide.jukalang.com/) and create a new file. The
IDE runs the same language as the desktop build, so every example on this site
works there unchanged. On a phone or tablet, use the browser menu to add the IDE
to your home screen.

### On your computer (portable build)

Juka does not need an installer or administrator rights.

1. Open [jukalang.com/download](/download).
2. Download the archive for your platform: Windows, macOS, Linux, ARM, or
   FreeBSD.
3. Unzip it into any folder — a thumb drive works too.
4. Open a terminal in that folder.

On macOS, Linux, and FreeBSD, make sure the interpreter is executable the first
time:

```bash
chmod +x juka
```

On Windows, use `juka.exe` in the commands below.

## 2. Run the interpreter

Start the interactive prompt:

```bash
./juka
```

Type a value and press Enter. Juka prints expressions unless you assign them:

```text
"Hello from Juka"
```

Leave the prompt with `Ctrl+D` (macOS/Linux) or `Ctrl+Z` then Enter (Windows).

## 3. Write your first file

Create a file named `HelloWorld.juk` with this content:

```jsx
func main() = {
  printLine("Hello World")
}
```

Run it:

```bash
./juka HelloWorld.juk
```

You should see:

```text
Hello World
```

That is the whole loop: edit a `.juk` file, run it with `./juka <file>`. There is
no separate build step for the interpreter.

## 4. Learn the language

You now have a working setup. These pages cover the rest in order:

- [Language fundamentals](/docs/fundamentals) — values, variables, arrays and
  conditions.
- [Variables](/docs/variables) and [strings](/docs/strings).
- [Classes](/docs/classes).
- [Examples](/examples) — small programs, including native parallel
  subroutines.

## 5. Build something else with it

- [JukaAPI](/docs/n5_online/api) runs Juka code from another service over HTTP.
- [Jupyter](/docs/n2_install/jupyter) runs Juka cells in a notebook.
- [Apps](/docs/appinstall) covers the desktop and Android apps.
- [JukaHub GUI builder](https://generate.jukalang.com) designs a handheld
  interface and exports its layout.

## If something does not work

- **`./juka: permission denied`** — run `chmod +x juka` once.
- **`./juka: command not found`** — you are not in the folder you unzipped;
  `cd` into it or run `./juka` with the full path.
- **macOS blocks the binary** — open System Settings → Privacy & Security and
  allow the downloaded file, or run it from Terminal after `chmod +x`.
- More answers are in the [FAQ](/docs/Other%20Content/faqs) and the
  [troubleshooting guide](/docs/Other%20Content/troubleshooting-mac).

Still stuck? Ask in the [Discord community](https://discord.gg/MsKWsErzfp) with
your operating system and the exact command you ran.
