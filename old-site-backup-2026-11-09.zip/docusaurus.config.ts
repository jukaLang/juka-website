// @ts-check
// Note: type annotations allow type checking and IDEs autocompletion

import PrismLight from './src/utils/prismLight';
import PrismDark from './src/utils/prismDark';

const siteUrl = 'https://jukalang.com';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Juka',
  alternateName: 'Juka Programming Language',
  url: siteUrl,
  logo: `${siteUrl}/img/logo.svg`,
  sameAs: [
    'https://github.com/jukaLang',
    'https://discord.gg/MsKWsErzfp',
    'https://twitter.com/jukaLang',
  ],
};

const websiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: 'Juka Programming Language',
  url: siteUrl,
  description:
    'The official home of Juka: a portable, easy-to-learn programming language for desktop, mobile, the browser and the cloud.',
  publisher: {'@type': 'Organization', name: 'Juka'},
};

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Juka Programming Language',
  tagline: 'A portable, easy-to-learn programming language',
  url: siteUrl,
  baseUrl: '/',
  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',
  favicon: 'img/favicon.png',
  organizationName: 'jukaLang',
  projectName: 'juka-website',

  headTags: [
    {
      tagName: 'script',
      attributes: {type: 'application/ld+json'},
      innerHTML: JSON.stringify(organizationSchema),
    },
    {
      tagName: 'script',
      attributes: {type: 'application/ld+json'},
      innerHTML: JSON.stringify(websiteSchema),
    },
    {
      tagName: 'meta',
      attributes: {property: 'og:site_name', content: 'Juka Programming Language'},
    },
    {
      tagName: 'meta',
      attributes: {property: 'og:image', content: `${siteUrl}/img/juka.png`},
    },
    {
      tagName: 'meta',
      attributes: {name: 'twitter:image', content: `${siteUrl}/img/juka.png`},
    },
  ],

  plugins: [
    [
      require.resolve('docusaurus-gtm-plugin'),
      {
        id: 'GTM-W6ZDC8V', // GTM Container ID
      },
    ],
      () => ({
        name: "inject-tag",
        injectHtmlTags() {
          // The Discord widget is heavy, so it is loaded only when the chat
          // button is pressed. A hidden iframe used to load on every page.
          return {
            postBodyTags: [`<button type="button" id="jukaChatToggle" class="juka-chat-toggle" aria-controls="jukaChatPanel" aria-expanded="false">Chat with the community</button>
<div id="jukaChatPanel" class="juka-chat-panel" hidden>
  <button type="button" class="juka-chat-close" id="jukaChatClose" aria-label="Close chat">×</button>
  <iframe title="Juka Discord community" id="jukaChatFrame" loading="lazy" height="600" width="800" allow="clipboard-write; fullscreen"></iframe>
</div>
<style>
.juka-chat-toggle{position:fixed;right:18px;bottom:18px;z-index:2147483000;border:0;border-radius:999px;padding:12px 18px;font-weight:700;cursor:pointer;color:#04231e;background:linear-gradient(135deg,#00e0bc,#25c2a0);box-shadow:0 10px 30px rgba(0,0,0,.28)}
.juka-chat-toggle:hover{filter:brightness(1.05)}
.juka-chat-panel{position:fixed;right:18px;bottom:74px;z-index:2147483000;width:min(820px,calc(100vw - 36px));height:min(620px,calc(100vh - 110px));background:#11151d;border:1px solid #283142;border-radius:14px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.5)}
.juka-chat-panel[hidden]{display:none}
.juka-chat-panel iframe{display:block;width:100%;height:100%;border:0}
.juka-chat-close{position:absolute;top:6px;right:8px;z-index:2;width:32px;height:32px;border:0;border-radius:50%;background:rgba(0,0,0,.45);color:#fff;font-size:20px;line-height:1;cursor:pointer}
@media (max-width:600px){.juka-chat-toggle{right:12px;bottom:12px;padding:10px 14px;font-size:14px}.juka-chat-panel{right:12px;bottom:64px;width:calc(100vw - 24px);height:calc(100vh - 96px)}}
</style>
<script>
(function(){
  var toggle=document.getElementById('jukaChatToggle');
  var panel=document.getElementById('jukaChatPanel');
  var close=document.getElementById('jukaChatClose');
  var frame=document.getElementById('jukaChatFrame');
  if(!toggle||!panel||!frame){return;}
  function open(){
    if(!frame.getAttribute('src')){
      frame.setAttribute('src','https://e.widgetbot.io/channels/975787212954275910/975787212954275916');
    }
    panel.hidden=false;
    toggle.setAttribute('aria-expanded','true');
    toggle.textContent='Hide chat';
  }
  function hide(){
    panel.hidden=true;
    toggle.setAttribute('aria-expanded','false');
    toggle.textContent='Chat with the community';
  }
  toggle.addEventListener('click',function(){panel.hidden?open():hide();});
  if(close){close.addEventListener('click',hide);}
})();
</script>`],
          };
        },
      }),
    [
      '@docusaurus/plugin-pwa',
      {
        pwaHead: [
          {
            tagName: 'link',
            rel: 'icon',
            href: '/img/juka.png',
          },
          {
            tagName: 'link',
            rel: 'manifest',
            href: '/manifest.json',
          },
          {
            tagName: 'meta',
            name: 'theme-color',
            content: 'rgb(51, 52, 71)',
          },
          {
            tagName: 'meta',
            name: 'apple-mobile-web-app-capable',
            content: 'yes',
          },
          {
            tagName: 'meta',
            name: 'apple-mobile-web-app-status-bar-style',
            content: 'rgb(51, 52, 71)',
          },
          {
            tagName: 'link',
            rel: 'apple-touch-icon',
            href: '/img/juka_app.png',
          },
          {
            tagName: 'link',
            rel: 'mask-icon',
            href: '/img/logo.svg',
            color: 'rgb(51, 52, 71)',
          },
          {
            tagName: 'meta',
            name: 'msapplication-TileImage',
            content: '/img/juka_app.png',
          },
          {
            tagName: 'meta',
            name: 'msapplication-TileColor',
            content: 'rgb(51, 52, 71)',
          },
        ],
      },
    ],
  ],

  i18n: {
    defaultLocale: 'en',
    locales: ['en','ru','zh','es','fr','de'],
  },
  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: require.resolve('./sidebars.js'),
        },
        blog: {
          showReadingTime: true,
        },
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      algolia: {
        appId: 'IQBWLWIGTM',
        // Public API key: it is safe to commit it
        apiKey: '6506f7fbc2f367f0f997aaddf3f404b9',
        indexName: 'jukalang',
        contextualSearch: true,
      },
      colorMode: {
        defaultMode: 'light',
        disableSwitch: false,
        respectPrefersColorScheme: true,
      },
      image: 'img/juka.png',
      metadata: [
        {
          name: 'keywords',
          content:
            'juka, programming language, portable language, cross-platform, learn programming, multithreading, webassembly, jukalang',
        },
        {name: 'twitter:card', content: 'summary_large_image'},
        {
          name: 'description',
          content:
            'Juka is a portable, easy-to-learn programming language with native multithreading, a package manager and Web2/Web3 targets. Try it online or download it for desktop, mobile, the browser or the cloud.',
        },
      ],
      announcementBar: {
        id: 'quickstart_cta',
        content:
            'New to Juka? <a target="_blank" rel="noopener noreferrer" href="/docs/quickstart">Take the ten-minute quickstart →</a>',
        backgroundColor: '#00e0bc',
        textColor: '#04231e',
        isCloseable: true,
      },
      navbar: {
        title: 'Juka',
        logo: {
          alt: 'Juka logo',
          src: 'img/logo.svg',
        },
        items: [
          {
            type: 'doc',
            docId: 'intro',
            position: 'left',
            label: 'Docs',
          },
          {
            to: 'learn',
            label: 'Learn',
            position: 'left'
          },
          {
            to: 'examples',
            label: 'Examples',
            position: 'left'
          },
          {
            to: 'download',
            label: 'Download',
            position: 'left'
          },
          {
            to: 'tools',
            label: 'Tools',
            position: 'left'
          },
          {
            to: 'community',
            label: 'Community',
            position: 'left'
          },
          {
            to: 'https://ide.jukalang.com/',
            label: 'Try Online',
            position: 'right'
          },
          {
            type: 'localeDropdown',
            position: 'right',
          },
          {
            href: 'https://github.com/jukaLang/JukaHubV2',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      footer: {
        copyright: `Copyright © ${new Date().getFullYear()} Juka Programming Language <br/> (Last updated on ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} EST)`,
        style: 'dark',
        links: [
          {
            title: 'Learn',
            items: [
              {
                label: 'Documentation',
                to: '/docs',
              },
              {
                label: 'Quickstart',
                to: '/docs/quickstart',
              },
              {
                label: 'Examples',
                to: '/examples',
              },
              {
                label: 'Language guide',
                to: '/learn',
              },
              {
                label: 'Download Juka',
                to: '/download',
              },
              {
                label: 'Try Online',
                to: 'https://ide.jukalang.com',
              },
            ],
          },
          {
            title: 'Community',
            items: [
              {
                label: 'Community hub',
                to: '/community',
              },
              {
                label: 'Discord',
                href: 'https://discord.gg/MsKWsErzfp',
              },
              {
                label: 'GitHub',
                href: 'https://github.com/jukaLang/JukaHubV2',
              },
              {
                label: 'Contributing guide',
                to: '/docs/Contributing to Juka Project/introdev',
              },
              {
                label: 'Twitter',
                href: 'https://twitter.com/jukaLang',
              },
              {
                label: 'YouTube',
                href: 'https://www.youtube.com/@jukalang'
              },
            ],
          },
          {
            title: 'More',
            items: [
              {
                label: 'Tools',
                to: '/tools',
              },
              {
                label: 'Changelog',
                to: '/changelog',
              },
              {
                label: 'Get Certificate',
                to: '/quiz',
              },
              {
                label: 'Donate',
                href: '/donate',
              },
              {
                label: 'Privacy',
                to: '/privacy',
              },
              {
                label: 'License',
                to: '/license',
              },
              {
                label: 'Contact Us',
                to: '/contact'
              },
              {
                label: 'JukaOS',
                href: 'https://os.jukalang.com/',
              },
            ],
          },
        ],
      },
      prism: {
        theme: PrismLight,
        darkTheme: PrismDark,
      },
    }),
};

module.exports = config;
