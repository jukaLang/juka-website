import React from 'react';
import clsx from 'clsx';
import styles from './HomepageFeatures.module.css';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {
  faFloppyDisk,
  faCode,
  faNetworkWired,
  faBoxOpen,
} from '@fortawesome/free-solid-svg-icons';
import Translate from '@docusaurus/Translate';

const FeatureList = [
  {
    title: (
      <Translate id="features.portable.title">Portable by design</Translate>
    ),
    icon: faFloppyDisk,
    description: (
      <Translate id="features.portable.body">
        A ~30 MB build that runs from a thumb drive, with no installer and no
        admin rights. Keep several versions side by side and carry your
        toolchain with you.
      </Translate>
    ),
  },
  {
    title: <Translate id="features.everywhere.title">Runs everywhere</Translate>,
    icon: faNetworkWired,
    description: (
      <Translate id="features.everywhere.body">
        Windows, macOS, Linux, ARM, FreeBSD, Android, and the browser through Web
        Assembly. The same program is not tied to one operating system or one
        cloud.
      </Translate>
    ),
  },
  {
    title: <Translate id="features.learn.title">Easy to learn</Translate>,
    icon: faCode,
    description: (
      <Translate id="features.learn.body">
        A familiar, Python-like surface with braces instead of indentation and
        static typing when you want it. Start in the browser and read one page
        before writing your first program.
      </Translate>
    ),
  },
  {
    title: (
      <Translate id="features.projects.title">Built for real projects</Translate>
    ),
    icon: faBoxOpen,
    description: (
      <Translate id="features.projects.body">
        Native multithreading with the &lt;=&gt; operator, a package manager,
        Jupyter support, a REST API, and Web2/Web3 targets — without a second
        toolchain to install.
      </Translate>
    ),
  },
];

function Feature({title, icon, description}) {
  return (
    <div className={clsx('col col--6', styles.featureCol)}>
      <div className={styles.featureCard}>
        <span className={styles.iconBadge}>
          <FontAwesomeIcon icon={icon} className={styles.icon} />
        </span>
        <h3 className={styles.featureTitle}>{title}</h3>
        <p className={styles.featureBody}>{description}</p>
      </div>
    </div>
  );
}

export default function HomepageFeatures() {
  return (
    <section className={styles.features}>
      <div className="container">
        <h2 className={styles.heading}>
          <Translate id="features.heading">Why Juka?</Translate>
        </h2>
        <div className={clsx('row', styles.featureRow)}>
          {FeatureList.map((props, idx) => (
            <Feature key={idx} {...props} />
          ))}
        </div>
      </div>
    </section>
  );
}
