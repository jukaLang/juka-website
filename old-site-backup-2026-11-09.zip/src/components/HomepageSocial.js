import React from 'react';
import styles from './HomepageSocial.module.css';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {
  faDiscord,
  faGithub,
  faTwitter,
  faYoutube,
  faFacebook,
  faInstagram,
} from '@fortawesome/free-brands-svg-icons';

const socials = [
  {icon: faDiscord, url: 'https://discord.gg/MsKWsErzfp', label: 'Discord'},
  {icon: faGithub, url: 'https://github.com/jukaLang/JukaHubV2', label: 'GitHub'},
  {icon: faTwitter, url: 'https://twitter.com/jukaLang', label: 'Twitter'},
  {icon: faYoutube, url: 'https://www.youtube.com/@jukalang', label: 'YouTube'},
  {icon: faFacebook, url: 'https://www.facebook.com/jukalang/', label: 'Facebook'},
  {
    icon: faInstagram,
    url: 'https://www.instagram.com/jukalanguage/',
    label: 'Instagram',
  },
];

export default function HomepageSocial() {
  return (
    <div className={styles.social} aria-label="Juka on social platforms">
      {socials.map((social) => (
        <a
          key={social.label}
          className={styles.link}
          href={social.url}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={social.label}
          title={social.label}>
          <FontAwesomeIcon icon={social.icon} className={styles.icon} />
        </a>
      ))}
    </div>
  );
}
