import React, {useEffect, useState} from 'react';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';
import styles from './changelog.module.css';

// Release notes come from the public repository that currently ships builds,
// so this page cannot fall behind what is actually released. If the request
// fails (offline, rate limit) the page still works as a link to that page.
const RELEASES_REPO = 'jukaLang/JukaHubV2';
const RELEASES_URL = `https://github.com/${RELEASES_REPO}/releases`;
const API_URL = `https://api.github.com/repos/${RELEASES_REPO}/releases?per_page=10`;
function formatDate(iso) {
  if (!iso) {
    return '';
  }
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return '';
  }
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function ReleaseCard({release}) {
  const name = release.name && release.name.trim() ? release.name.trim() : release.tag_name;
  const body = typeof release.body === 'string' ? release.body.trim() : '';
  const shown = body.length > 1400 ? `${body.slice(0, 1400).trimEnd()}…` : body;
  // Automated builds often carry no notes at all. Their value is the artifact,
  // so list the downloadable files instead of an empty card.
  const assets = (Array.isArray(release.assets) ? release.assets : []).filter(
    (asset) => asset && asset.name && asset.browser_download_url,
  );

  return (
    <article className={styles.release}>
      <header className={styles.releaseHead}>
        <h2 className={styles.releaseTitle}>
          <a href={release.html_url} rel="noopener noreferrer">
            {name}
          </a>
        </h2>
        <p className={styles.releaseMeta}>
          <span className={styles.tag}>{release.tag_name}</span>
          <time dateTime={release.published_at}>{formatDate(release.published_at)}</time>
          {release.prerelease && <span className={styles.badge}>pre-release</span>}
        </p>
      </header>
      {shown ? (
        <pre className={styles.releaseBody}>{shown}</pre>
      ) : (
        <p className={styles.releaseBody}>
          This build has no release notes. Download it directly:
        </p>
      )}
      {assets.length > 0 && (
        <ul className={styles.assets}>
          {assets.map((asset) => (
            <li key={asset.name}>
              <a href={asset.browser_download_url} rel="noopener noreferrer">
                {asset.name}
              </a>
            </li>
          ))}
        </ul>
      )}
      <a className={styles.releaseLink} href={release.html_url} rel="noopener noreferrer">
        {body.length > 1400 ? 'Read the full notes on GitHub →' : 'Open this release on GitHub →'}
      </a>
    </article>
  );
}

export default function Changelog() {
  const [releases, setReleases] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const response = await fetch(API_URL, {headers: {Accept: 'application/vnd.github+json'}});
        if (!response.ok) {
          throw new Error(`GitHub returned ${response.status}`);
        }
        const result = await response.json();
        if (cancelled) {
          return;
        }
        if (!Array.isArray(result) || result.length === 0) {
          setFailed(true);
          return;
        }
        setReleases(result);
      } catch (err) {
        if (!cancelled) {
          console.log('Cannot load the release list: ' + err);
          setFailed(true);
        }
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <Layout
      title="Juka changelog"
      description="Recent JukaHub releases with their notes and download links, newest first.">
      <main className={styles.page}>
        <div className={`container ${styles.narrow}`}>
          <header className={styles.hero}>
            <p className={styles.eyebrow}>Changelog</p>
            <h1 className={styles.title}>What changed, release by release</h1>
            <p className={styles.lead}>
              Juka ships often. This page lists the most recent JukaHub builds
              straight from the repository, so the notes you read here are the
              same ones the maintainers wrote. Compiler packages continue to be
              published on <a href="https://www.nuget.org/packages/JukaCompiler">NuGet</a>,
              and the browser build needs no download at all.
            </p>
            <div className={styles.linkRow}>
              <Link className={styles.button} to="/download">
                Download the latest version
              </Link>
              <a
                className={styles.textLink}
                href={RELEASES_URL}
                rel="noopener noreferrer">
                All releases on GitHub →
              </a>
            </div>
          </header>

          {releases === null && !failed && (
            <p className={styles.status} role="status">
              Loading the release history…
            </p>
          )}

          {failed && (
            <div className={styles.fallback} role="status">
              <p>
                The release list could not be loaded here — GitHub may be
                unreachable or the request limit was reached. Nothing is missing
                from the project: the full history lives on GitHub.
              </p>
              <a href={RELEASES_URL} rel="noopener noreferrer">
                Open the releases on GitHub →
              </a>
            </div>
          )}

          {releases !== null && (
            <section className={styles.list} aria-label="Recent releases">
              {releases.map((release) => (
                <ReleaseCard key={release.id ?? release.tag_name} release={release} />
              ))}
            </section>
          )}

          <p className={styles.note}>
            New to Juka? The <Link to="/docs/quickstart">quickstart</Link> takes
            about ten minutes, and every example on the{' '}
            <Link to="/examples">examples page</Link> runs in the{' '}
            <a href="https://ide.jukalang.com/">online IDE</a>.
          </p>
        </div>
      </main>
    </Layout>
  );
}
