import React from 'react';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';
import styles from './infoPages.module.css';

const channels = [
  {
    title: 'Discord',
    description:
      'The fastest place to ask a question, share what you built, or follow release chatter. Beginners are welcome.',
    href: 'https://discord.gg/MsKWsErzfp',
    cta: 'Join the Discord',
    primary: true,
  },
  {
    title: 'GitHub',
    description:
      'The public repositories that ship today: the JukaHub app, the package registry and the surrounding tools. Star what you use, or open a pull request.',
    href: 'https://github.com/jukaLang/JukaHubV2',
    cta: 'Open the repository',
  },
  {
    title: 'Contributor guide',
    description:
      'How to report a bug, propose a feature, write documentation, or send code that fits the project style.',
    href: '/docs/Contributing%20to%20Juka%20Project/introdev',
    cta: 'Read the guide',
  },
  {
    title: 'Issues and ideas',
    description:
      'Browse what is already reported before filing. Small, focused issues are the easiest ones to fix.',
    href: 'https://github.com/jukaLang/JukaHubV2/issues',
    cta: 'Browse issues',
  },
  {
    title: 'Contribute hub',
    description:
      'GitHub’s contributor view lists the issues the maintainers have marked as a good place to start.',
    href: 'https://github.com/jukaLang/JukaHubV2/contribute',
    cta: 'Find a first issue',
  },
  {
    title: 'Releases',
    description:
      'Every app release, with downloads and notes. Watch the repository to hear about the next one.',
    href: 'https://github.com/jukaLang/JukaHubV2/releases',
    cta: 'See releases',
  },
];

export default function Community() {
  return (
    <Layout
      title="Juka community"
      description="Join the Juka community on Discord and GitHub, contribute to the compiler or documentation, and follow new releases.">
      <main className={styles.page}>
        <div className="container">
          <header className={styles.hero}>
            <p className={styles.eyebrow}>Community</p>
            <h1 className={styles.title}>Built in the open</h1>
            <p className={styles.lead}>
              Juka is a community project: the compiler, this website, the
              packages and the handheld tools are all developed in public. Ask a
              question, report what broke, or help with the next release — there
              is room at every level.
            </p>
            <div className={styles.linkRow}>
              <a
                className={styles.button}
                href="https://discord.gg/MsKWsErzfp"
                rel="noopener noreferrer">
                Join the Discord
              </a>
              <a
                className={styles.textLink}
                href="https://github.com/jukaLang/JukaHubV2"
                rel="noopener noreferrer">
                Contribute on GitHub →
              </a>
            </div>
          </header>

          <div className={styles.grid}>
            {channels.map((channel) => (
              <article
                key={channel.title}
                className={
                  channel.primary
                    ? `${styles.card} ${styles.cardPrimary}`
                    : styles.card
                }>
                <h2>{channel.title}</h2>
                <p>{channel.description}</p>
                <a
                  className={styles.cardLink}
                  href={channel.href}
                  rel="noopener noreferrer">
                  {channel.cta} →
                </a>
              </article>
            ))}
          </div>

          <h2 className={styles.sectionTitle}>Ways to help that are not code</h2>
          <ul className={styles.list}>
            <li>Write or fix a page in the documentation, and send it the way the contributing guide describes.</li>
            <li>Translate a page into a language you know well, and keep it current.</li>
            <li>Report a bug with the exact platform, version and steps to reproduce it.</li>
            <li>Answer a question in Discord, or show a project you built with Juka.</li>
          </ul>

          <p className={styles.note}>
            Looking for what shipped recently? The <Link to="/changelog">changelog</Link>{' '}
            lists the last ten releases with their notes.
          </p>

          <p className={styles.note}>
            New to the language? The <Link to="/docs/quickstart">quickstart</Link>{' '}
            takes about ten minutes, and the{' '}
            <Link to="/docs/Other%20Content/faqs">FAQ</Link> answers the questions people ask
            first.
          </p>
        </div>
      </main>
    </Layout>
  );
}
