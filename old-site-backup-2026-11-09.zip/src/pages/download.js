import React, {useEffect, useState} from 'react';
import Layout from '@theme/Layout';
import useDocusaurusContext from '@docusaurus/useDocusaurusContext';
import styles from "./download.module.css";
import clsx from "clsx";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faServer, faFileCode, faCode,faPuzzlePiece,faDesktopAlt,faSun,faCross,faBook,faGlobe,faRobot} from '@fortawesome/free-solid-svg-icons'
import { faChrome,faWindows, faApple, faLinux, faFreebsd, faRaspberryPi,faPython,faAndroid,faAppStoreIos,faUnity,faAmazon} from '@fortawesome/free-brands-svg-icons'
import BrowserOnly from "@docusaurus/BrowserOnly";
import Link from "@docusaurus/Link";

// The publicly distributed app builds live in JukaHubV2, so the page reads that
// repository instead of relying on a fixed version string.
const APP_REPO = 'https://github.com/jukaLang/JukaHubV2';
const COMPILER_VERSION = "1.0.0";

// The platform matrix points at compiler release assets. While the compiler
// repository is not public those URLs are dead, so the page offers the online
// IDE and the NuGet package instead. Set this to false when the binaries are
// published again; the full per-platform instructions are still below.
const COMPILER_DOWNLOADS_PAUSED = true;

function DownloadHeader() {

    // Compiler binaries are versioned separately from the app builds. The
    // compiler package is published on NuGet; the app releases come from GitHub.
    const [version] = useState(COMPILER_VERSION);
    const [appRelease, setAppRelease] = useState(null);

    useEffect(() => {
        let cancelled = false;
        const loadLatest = async () => {
            try {
                const response = await fetch('https://api.github.com/repos/jukaLang/JukaHubV2/releases/latest');
                if (!response.ok) {
                    return;
                }
                const result = await response.json();
                if (cancelled || !result || !result.tag_name) {
                    return;
                }
                setAppRelease({
                    tag: result.tag_name,
                    body: typeof result.body === 'string' ? result.body.trim() : '',
                    html_url: result.html_url || APP_REPO + '/releases',
                    assets: Array.isArray(result.assets) ? result.assets : [],
                });
            } catch (err) {
                console.log("Cannot access GitHub: " + err);
            }
        };
        loadLatest();
        return () => {
            cancelled = true;
        };
    }, []);

    const assetUrl = (name) => {
        if (!appRelease) {
            return APP_REPO + '/releases/latest';
        }
        const asset = appRelease.assets.find((item) => item && item.name === name);
        return asset && asset.browser_download_url ? asset.browser_download_url : appRelease.html_url;
    };

    function BigDownloadList() {
        return (
            <section className={styles.features}>
                <div className="container">
                    <div className="row">
                        {OSList.map((props, idx) => (
                            <OSTag key={idx} {...props} />
                        ))}
                    </div>
                </div>
            </section>
        );
    }
    const OSList = [
        {
            title: "Windows",
            faIcon: {faWindows}.faWindows,
            description: (
                <>
                    <b>Windows Version {version}:</b><br/>
                    <br/>
                    Juka (x64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Windows_X64_"+version+".zip"} >Download</a><br/>
                    Juka API (x64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Windows_X64_"+version+".zip"} >Download</a><br/><br/>

                    Juka (x86-32bit):  <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Windows_X86_"+version+".zip"} >Download</a><br/>
                    Juka API (x86-32bit):  <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Windows_X86_"+version+".zip"} >Download</a><br/><br/>

                    Juka (ARM64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Windows_Arm64_"+version+".zip"} >Download</a><br/>
                    Juka API (ARM64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Windows_Arm64_"+version+".zip"} >Download</a><br/><br/>

                    Juka App: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/JukaApp/releases/download/"+version+"/Juka_Windows_App_"+version+".msix"} >Download</a><br/>
                    Windows Store: <i>In active development, coming soon!</i><br/><br/>
                    
                </>
            ),
        },
        {
            title: "MacOS (Macintosh)",
            faIcon: {faApple}.faApple,
            description: (
                <>
                    <b>MacOS Version {version}:</b><br/>
                    <br/>
                    Juka: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_MacOS_X64_"+version+".zip"} >Download</a><br/>
                    Juka API: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_MacOS_X64_"+version+".zip"} >Download</a><br/>
                </>
            ),
        },
        {
            title: "Linux (32 and 64 bit)",
            faIcon: {faLinux}.faLinux,
            description: (
                <>
                    <b>Linux Version {version}:</b><br/>
                    <br/>
                    Juka (x64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_X64_"+version+".zip"} >Download</a><br/>
                    Juka API (x64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Linux_X64_"+version+".zip"} >Download</a><br/><br/>

                    Juka (x86-32bit):  <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_X86_"+version+".tar.gz"} >Download</a><br/>
                    Juka API (x86-32bit):  <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_X86_"+version+".tar.gz"} >Download</a><br/><br/>

                    Juka (ARM): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_Arm_"+version+".zip"} >Download</a><br/>
                    Juka API (ARM): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Linux_Arm_"+version+".zip"} >Download</a><br/><br/>

                    Juka (ARM64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_Arm64_"+version+".zip"} >Download</a><br/>
                    Juka API (ARM64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_Arm64_"+version+".zip"} >Download</a><br/>
                </>
            ),
        },
        {
            title: "FreeBSD and Unix",
            faIcon: {faFreebsd}.faFreebsd,
            description: (
                <>
                    <b>FreeBSD Version {version}:</b><br/>
                    <br/>
                    Juka: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Unix_X64_"+version+".tar.gz"} >Download</a><br/>
                    Juka API: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Unix_X64_"+version+".tar.gz"} >Download</a><br/>
                </>
            ),
        },
        {
            title: "iOS and iPadOS",
            faIcon: {faAppStoreIos}.faAppStoreIos,
            description: (
                <>
                    <b>iOS Version {version}:</b><br/>
                    <br/>
                    IDE (Browser Based App): <a rel="noopener noreferrer" href={"https://ide.jukalang.com"} target={"_blank"}>https://ide.jukalang.com</a><br/>
                    Native App: <i>In active development, coming soon!</i>
                </>
            ),
        },
        {
            title: "Android and AndroidTV",
            faIcon: {faAndroid}.faAndroid,
            description: (
                <>
                    <b>Android Version {version}:</b><br/>
                    <br/>
                    IDE (Browser Based App): <a rel="noopener noreferrer" href={"https://ide.jukalang.com"} target={"_blank"}>https://ide.jukalang.com</a><br/>
                    Sideload Juka App: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/JukaApp/releases/download/"+version+"/Juka_Android_App_"+version+".apk"} >Download</a><br/>
                    Google PlayStore: <i>In active development, coming soon!</i>
                </>
            ),
        },

        {
            title: "ChromeOS and ChromeOS Flex",
            faIcon: {faChrome}.faChrome,
            description: (
                <>
                    <b>ChromeOS (Flex) Version {version}:</b><br/>
                    <br/>
                    Go to and click install:  <a href={"https://ide.jukalang.com"} target={"_blank"}>https://ide.jukalang.com</a><br/>
                </>
            ),
        },

        {
            title: "Amazon Fire and Amazon Fire HD",
            faIcon: {faAmazon}.faAmazon,
            description: (
                <>
                    <b>Amazon Fire (HD) Version {version}:</b><br/>
                    <br/>
                    IDE (Browser Based App): <a rel="noopener noreferrer" href={"https://ide.jukalang.com"} target={"_blank"}>https://ide.jukalang.com</a><br/>
                    Sideload Juka App: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/JukaApp/releases/download/"+version+"/Juka_Android_App_"+version+".apk"} >Download</a><br/>
                    Amazon Appstore: <i>In active development, coming soon!</i>
                </>
            ),
        },

        {
            title: "Tizen (Samsung)",
            faIcon: {faSun}.faSun,
            description: (
                <>
                    <b>Tizen (Samsung) Version {version}:</b><br/>
                    <br/>
                    IDE (Browser Based App): <a rel="noopener noreferrer" href={"https://ide.jukalang.com"} target={"_blank"}>https://ide.jukalang.com</a><br/>
                    Native App: <i>In active development, coming soon!</i>
                </>
            ),
        },

        {
            title: "Microsoft Azure Server",
            faIcon: {faServer}.faServer,
            description: (
                <>
                    <b>Azure Version {version}:</b><br/>
                    <br/>
                    Juka: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Azure_Function_"+version+".zip"}>Download</a><br/>
                </>
            ),
        },

        {
            title: "Raspberry Pi",
            faIcon: {faRaspberryPi}.faRaspberryPi,
            description: (
                <>
                    <b>RespberryPi Version {version}:</b><br/>
                    <br/>
                    Juka: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_Arm_"+version+".zip"} >Download</a><br/>
                    Juka API: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Linux_Arm_"+version+".zip"} >Download</a><br/><br/>

                    Juka (Pi 3+): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_Arm64_"+version+".zip"} >Download</a><br/>
                    Juka API (Pi 3+): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Linux_Arm64_"+version+".zip"} >Download</a><br/><br/>

                    Juka (Win ARM64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Windows_Arm64_"+version+".zip"} >Download</a><br/>
                    Juka API (Win ARM64): <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/JukaAPI_Windows_Arm64_"+version+".zip"} >Download</a><br/>
                </>
            ),
        },
        {
            title: "Jupyter Kernel",
            faIcon: {faPython}.faPython,
            description: (
                <>
                    <b>Jupyter Kernel Version 0.2:</b><br/>
                    <br/>
                    Download from PyPI:  <code>pip install juka-kernel</code><br/>
                    Package page: <a rel="noopener noreferrer" href={"https://pypi.org/project/juka-kernel/"} target={"_blank"}>pypi.org/project/juka-kernel</a><br/>
                </>
            ),
        },
        {
            title: "C# DLL",
            faIcon: {faFileCode}.faFileCode,
            description: (
                <>
                    <b>C# .dll Version {version}:</b><br/>
                    <br/>
                    NuGet: Search for JukaCompiler or run <code>Install-Package JukaCompiler -version {version}</code><br/>
                    .dll lib: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/releases/download/"+version+"/Juka_Compiler_dll_"+version+".zip"} >Download</a><br/>
                </>
            ),
        },
        {
            title: "Unity",
            faIcon: {faUnity}.faUnity,
            description: (
                <>
                    <b>Unity Version {version}:</b><br/>
                    <br/>
                    Download from NuGet.org:  <a rel="noopener noreferrer" href={"https://www.nuget.org/api/v2/package/JukaCompiler"}>Download</a><br/>
                    Other Versions: <a rel="noopener noreferrer" href={"https://www.nuget.org/packages/JukaCompiler"} target={"_blank"}>Download</a><br/>
                </>
            ),
        },
        {
            title: "Web Assembly",
            faIcon: {faPuzzlePiece}.faPuzzlePiece,
            description: (
                <>
                    <b>Web Assembly Version {version}:</b><br/>
                    <br/>
                    Latest:  <a rel="noopener noreferrer" href={"https://github.com/jukaLang/JukaIDE/releases/download/"+version+"/Juka_IDE_"+version+".zip"} >Download version {version}</a><br/>
                    Repo Download: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/JukaIDE"} target={"_blank"} >Download</a><br/><br/>

                    Online: <a rel="noopener noreferrer" href={"https://ide.jukalang.com"} target={"_blank"} >https://ide.jukalang.com</a><br/>
                </>
            ),
        },
        {
            title: "Bots",
            faIcon: {faRobot}.faRobot,
            description: (
                <>
                    <b>Bot Version {version}:</b><br/>
                    <br/>
                    Telegram: Message @jukaLangBot<br/>
                    Discord (for your channel): <a rel="noopener noreferrer" href={"https://t.co/OaOE0TtvVK"} target={"_blank"} >Install App</a><br/><br/>

                    Discord (our channel): <a rel="noopener noreferrer" href={"https://discord.gg/MsKWsErzfp"} target={"_blank"} >https://discord.gg/MsKWsErzfp</a><br/>
                </>
            ),
        },
        {
            title: "Temple OS",
            faIcon: {faCross}.faCross,
            description: (
                <>
                    <b>TempleOS:</b><br/>
                    <br/>
                    Follow Instructions:  <a rel="noopener noreferrer" href={"https://github.com/jukaLang/JukaForTempleOS"} target={"_blank"} >https://github.com/jukaLang/JukaForTempleOS</a><br/>
                </>
            ),
        },
        {
            title: "Virtual Machine Image",
            faIcon: {faDesktopAlt}.faDesktopAlt,
            description: (
                <>
                    <b>VM Image:</b><br/>
                    <br/>
                    VirtualBox Image Download: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/jukaVM/releases/download/0.0.1/JukaVM.ova"} >Download</a><br/>
                    Download other versions: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/jukaVM/releases"} target={"_blank"} >Download</a><br/>
                </>
            ),
        },
        {
            title: "Online Versions",
            faIcon: {faGlobe}.faGlobe,
            description: (
                <>
                    <b>Online Versions:</b><br/>
                    <br/>
                    API: <a rel="noopener noreferrer" href={"https://api.jukalang.com"} target={"_blank"}>https://api.jukalang.com</a><br/>
                    Web IDE (Can run locally): <a rel="noopener noreferrer" href={"https://ide.jukalang.com"} target={"_blank"}>https://ide.jukalang.com</a><br/>
                </>
            ),
        },
        {
            title: "Documentation",
            faIcon: {faBook}.faBook,
            description: (
                <>
                    <b>Documentation:</b><br/>
                    <br/>
                    PDF: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/juka-website/releases/download/JukaLang/jukadocs.pdf"} >Download</a><br/>
                    You can also install the Juka Website App by bookmarking the page on mobile device, or on desktop by clicking the install app button near the URL bar.
                </>
            ),
        },
        {
            title: "Build From Source",
            faIcon: {faCode}.faCode,
            description: (
                <>
                    <b>Source Version {version}:</b><br/>
                    <br/>
                    Latest: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka/archive/refs/tags/"+version+".zip"}>Download</a><br/>
                    Other Versions: <a rel="noopener noreferrer" href={"https://github.com/jukaLang/Juka"} target={"_blank"}>Build</a><br/>
                </>
            ),
        },
    ];

    function OSTag({title, faIcon, description}) {
        return (
            <div className={clsx('col col--4', styles.fontagap)}>
                <div className="text--center padding-horiz--md">

                    <FontAwesomeIcon icon={faIcon} className={styles.fontawe} />
                    <br/><br/>
                    <h3>{title}</h3>
                    <p>{description}</p>
                </div>
            </div>
        );
    }

    const TryDetectDownload = () => {
        return (
            <BrowserOnly>
                {() => {
                    let userAgent = window.navigator.userAgent,
                        platform = window.navigator?.userAgentData?.platform || window.navigator.platform,
                        macosPlatforms = ['Macintosh', 'MacIntel', 'MacPPC', 'Mac68K'],
                        windowsPlatforms = ['Win32', 'Win64', 'Windows', 'WinCE'],
                        iosPlatforms = ['iPhone', 'iPad', 'iPod'];


                    let userOSEntry = {};
                    if (macosPlatforms.indexOf(platform) !== -1) {
                        if(navigator.maxTouchPoints > 0){
                            userOSEntry = OSList[4]; //iPadOS
                        } else {
                            userOSEntry = OSList[1]; //Mac
                        }
                    } else if (iosPlatforms.indexOf(platform) !== -1) {
                        userOSEntry = OSList[4];
                    } else if (windowsPlatforms.indexOf(platform) !== -1) {
                        userOSEntry = OSList[0];
                    } else if(/(?:; ([^;)]+) Build\/.*)?\bSilk\/([0-9._-]+)\b(.*\bMobile Safari\b)?/.test(userAgent)) {
                        userOSEntry = OSList[7];
                    } else if (/Android/.test(userAgent)) {
                        userOSEntry = OSList[5];
                    } else if (/TV/.test(userAgent)) {
                        userOSEntry = OSList[5];
                    } else if (/Linux/.test(platform)) {
                        if (userAgent.indexOf('Win64')){
                            userOSEntry = OSList[5];  //(some) Android TV Browsers
                        }
                        userOSEntry = OSList[2]; //Actual Linux
                    } else if (userAgent.indexOf('X11') !== -1) {
                        userOSEntry = OSList[3];
                    } else if (userAgent.indexOf('CrOS') !== -1) {
                        userOSEntry = OSList[6];
                    }

                    return (Object.keys(userOSEntry).length !== 0) ? (<><h3>It seems that you are using {userOSEntry.title}: </h3>
                        <section className={styles.features}>
                            <div className="container">
                                <div className="row">
                                    <div className={clsx('col col--4')} />
                                    <OSTag {...userOSEntry} />
                                </div>
                            </div>
                        </section></>) : (<>

                        <h3>Your current OS doesn't seem to be supported by Juka right now. Try using the IDE (Web App) version:</h3>

                            <section className={styles.features}>
                                <div className="container">
                                    <div className="row">
                                        <div className={clsx('col col--4')} />
                                        <OSTag {...OSList[10]} />
                                    </div>
                                </div>
                            </section>
                        </>)
                }
                }
            </BrowserOnly>
        );
    };



    return (
        <header>
            <h1 className={styles.Header}>Download Juka</h1>
            <div className={styles.learn}>
                <section className={styles.notice}>
                    <p>
                        <strong>Compiler binaries are paused while the compiler
                        repository is being restructured.</strong> Nothing about the
                        language changed: run it in the
                        {' '}<a href="https://ide.jukalang.com/" rel="noopener noreferrer">online IDE</a>{' '}
                        with no download, or add the compiler package from
                        {' '}<a href="https://www.nuget.org/packages/JukaCompiler" rel="noopener noreferrer">NuGet</a>{' '}
                        (JukaCompiler {version}). The app builds below are the
                        ones that ship today.
                    </p>
                </section>

                {COMPILER_DOWNLOADS_PAUSED ? (
                    <section className={styles.features}>
                        <div className="container">
                            <div className="row">
                                <div className={clsx('col col--4')} />
                                <div className={clsx('col col--4', styles.fontagap)}>
                                    <div className={clsx("text--center padding-horiz--md", styles.changelog2)}>
                                        <strong>Start here:</strong><br/><br/>
                                        Run Juka in the browser — nothing to install:{' '}
                                        <a href="https://ide.jukalang.com/" rel="noopener noreferrer">ide.jukalang.com</a><br/>
                                        Add the compiler to a .NET project:{' '}
                                        <a href="https://www.nuget.org/packages/JukaCompiler" rel="noopener noreferrer">JukaCompiler on NuGet</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                ) : (
                    <TryDetectDownload/>
                )}

                <br/>
                <h2>Latest app releases</h2>
                <section className={styles.changelog}>
                    <div className="container">
                        <div className="row">
                            <div className={clsx('col col--4')} />
                            <div className={clsx('col col--4', styles.fontagap)}>
                                <div className={clsx("text--center padding-horiz--md",styles.changelog2)}>
                                    {appRelease ? (
                                        <>
                                            <strong>New in {appRelease.tag}:</strong>{' '}
                                            {appRelease.body ? appRelease.body.slice(0, 400) : 'see the release notes on GitHub'}
                                        </>
                                    ) : (
                                        <>
                                            <strong>JukaHub builds</strong> — the newest
                                            release is fetched from GitHub.
                                        </>
                                    )}
                                    <br/><br/>
                                    JukaHub for a handheld:{' '}
                                    <a rel="noopener noreferrer" href={assetUrl('JukaHub-Trimui.zip')}>Download</a><br/>
                                    JukaHub for Windows:{' '}
                                    <a rel="noopener noreferrer" href={assetUrl('JukaHub-Windows.zip')}>Download</a>
                                    <br/><br/>
                                    <strong>New in the handheld build:</strong>{' '}
                                    LAN play. Link-cable games — Game Boy, Game Boy
                                    Advance, SNES, Mega Drive — run over Wi-Fi between
                                    two handhelds: host on one, join from the other
                                    with the address it shows. Both sides need
                                    RetroArch with a netplay core and the same ROM;
                                    PSP and Nintendo DS stay on their own local modes.
                                    <br/><br/>
                                    <strong>Every release and nightly build:</strong><br/>
                                    <a rel="noopener noreferrer" href={APP_REPO + '/releases'} target={"_blank"}>{APP_REPO}/releases</a>
                                    <br/><br/>
                                    <strong>Want the history instead of the binaries?</strong><br/>
                                    <Link to="/changelog">See the full changelog</Link>
                                    <br/><br/>
                                    <strong>Want to try Juka without downloading anything?</strong><br/>
                                    <a href="https://ide.jukalang.com/">Click here to try Juka Online</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <br/><br/>
                {COMPILER_DOWNLOADS_PAUSED ? (
                    <>
                        <h2>Supported platforms</h2>
                        <p>
                            These are the platforms Juka targets. Binary downloads
                            come back with the compiler repository; until then the
                            online IDE and NuGet cover every platform listed here.
                        </p>
                        <ul className={styles.platforms}>
                            {OSList.map(({title}) => (
                                <li key={title}>{title}</li>
                            ))}
                        </ul>
                    </>
                ) : (
                    <>
                        <h2> List of all available Downloads:</h2>
                        <BigDownloadList/>
                    </>
                )}
            </div>
        </header>
    )
}

export default function Home() {

    const {siteConfig} = useDocusaurusContext();
    return (
        <Layout
            title={`Download | ${siteConfig.title}`}
            description="Download Juka Programming Language">

            <main>
                <DownloadHeader />
            </main>
        </Layout>
    );
}
