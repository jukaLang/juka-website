import React from 'react';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';
import CodeExamples from '../components/CodeExamples';
import styles from './infoPages.module.css';

export default function Examples() {
  return (
    <Layout
      title="Juka examples"
      description="Short, runnable Juka examples: hello world, conditions, arrays, subroutines, loops, and native multithreading.">
      <main className={styles.page}>
        <div className="container">
          <header className={styles.hero}>
            <p className={styles.eyebrow}>Examples</p>
            <h1 className={styles.title}>Juka by example</h1>
            <p className={styles.lead}>
              Six small programs that show the syntax, the named arrays, and the
              native parallel subroutines. Every example runs unchanged in the
              online IDE, so you can edit one and see the result immediately.
            </p>
            <div className={styles.linkRow}>
              <a className={styles.button} href="https://ide.jukalang.com/">
                Open the online IDE
              </a>
              <Link className={styles.textLink} to="/docs/quickstart">
                Read the quickstart →
              </Link>
            </div>
          </header>

          <div className={styles.codeDemo}>
            <CodeExamples />
          </div>

          <h2 className={styles.sectionTitle}>Where to go next</h2>
          <ul className={styles.list}>
            <li>
              <Link to="/docs/fundamentals">Language fundamentals</Link> — types,
              arrays, conditions and classes.
            </li>
            <li>
              <Link to="/docs/hello-world">Your first application</Link> — create
              a file and run it from the console.
            </li>
            <li>
              <Link to="/docs/install">Install Juka</Link> — the portable build
              for Windows, macOS, Linux and FreeBSD.
            </li>
            <li>
              <Link to="/docs/n5_online/api">JukaAPI</Link> — run Juka over HTTP
              from another service.
            </li>
          </ul>

          <p className={styles.note}>
            The examples are intentionally small. For complete programs, work
            through the <Link to="/docs/quickstart">quickstart</Link> and the
            language guide, then try them in the online IDE.
          </p>
        </div>
      </main>
    </Layout>
  );
}
