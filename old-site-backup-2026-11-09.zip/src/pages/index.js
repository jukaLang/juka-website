import React from 'react';
import clsx from 'clsx';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';
import Head from '@docusaurus/Head';
import useDocusaurusContext from '@docusaurus/useDocusaurusContext';
import styles from './index.module.css';
import HomepageFeatures from '../components/HomepageFeatures';
import HomepageSocial from '../components/HomepageSocial';
import QandA from '../components/QuestionsAnswers';
import CodeExamples from '../components/CodeExamples';
import Translate from '@docusaurus/Translate';

const platforms = ['Windows', 'macOS', 'Linux', 'ARM', 'FreeBSD', 'Browser', 'Android'];

const softwareSchema = {
  '@context': 'https://schema.org',
  '@type': 'SoftwareApplication',
  name: 'Juka',
  applicationCategory: 'DeveloperApplication',
  applicationSubCategory: 'Programming language',
  operatingSystem: 'Windows, macOS, Linux, FreeBSD, Android, Web',
  description:
    'Juka is a portable, easy-to-learn programming language with native multithreading, a package manager, and Web2/Web3 targets. Write once and run it on desktop, mobile, the browser, or the cloud.',
  url: 'https://jukalang.com/',
  downloadUrl: 'https://jukalang.com/download',
  codeRepository: 'https://github.com/jukaLang/JukaHubV2',
  offers: {'@type': 'Offer', price: '0', priceCurrency: 'USD'},
  sameAs: [
    'https://github.com/jukaLang/JukaHubV2',
    'https://discord.gg/MsKWsErzfp',
    'https://twitter.com/jukaLang',
  ],
};

function HomepageHeader() {
  return (
    <header className={styles.hero}>
      <div className={clsx('container', styles.heroInner)}>
        <p className={styles.eyebrow}>
          <Translate id="home.eyebrow">Juka programming language</Translate>
        </p>
        <h1 className={styles.heroTitle}>
          <Translate id="home.title.one">One language.</Translate>
          <br />
          <span className={styles.heroAccent}>
            <Translate id="home.title.every">Every device.</Translate>
          </span>
        </h1>
        <p className={styles.heroLead}>
          <Translate id="home.lead">
            Juka is a portable, easy-to-learn programming language for beginners,
            makers, and teams building cross-platform tools. Write your program
            once and run it on desktop, mobile, a browser tab, or the cloud.
          </Translate>
        </p>
        <div className={styles.heroActions}>
          <Link className={styles.primaryCta} to="https://ide.jukalang.com/">
            <Translate id="home.cta.try">Try Juka Online</Translate>
            <span aria-hidden="true"> ↗</span>
          </Link>
          <Link className={styles.secondaryCta} to="/download">
            <Translate id="home.cta.download">Download Juka</Translate>
          </Link>
          <Link className={styles.tertiaryCta} to="/docs/quickstart">
            <Translate id="home.cta.quickstart">Read the quickstart →</Translate>
          </Link>
        </div>
        <p className={styles.heroNote}>
          <Translate id="home.note">
            No install needed in the browser · Free and open source · ~30 MB
            portable build
          </Translate>
        </p>
        <ul className={styles.platformList} aria-label="Supported platforms">
          {platforms.map((platform) => (
            <li key={platform}>{platform}</li>
          ))}
        </ul>
      </div>
    </header>
  );
}

function StartSteps() {
  return (
    <section className={styles.startSection}>
      <div className="container">
        <h2 className={styles.sectionTitle}>
          <Translate id="home.start.title">Start in three steps</Translate>
        </h2>
        <p className={styles.sectionLead}>
          <Translate id="home.start.lead">
            Pick the path that fits what you are doing. All three lead to the
            same language and the same documentation.
          </Translate>
        </p>
        <div className={styles.stepGrid}>
          <article className={styles.stepCard}>
            <span className={styles.stepNumber}>01</span>
            <h3>
              <Translate id="home.start.browser.title">Try it in your browser</Translate>
            </h3>
            <p>
              <Translate id="home.start.browser.body">
                The online IDE runs Juka on any device — no download, no setup.
                It is the fastest way to see the syntax for yourself.
              </Translate>
            </p>
            <Link className={styles.cardLink} to="https://ide.jukalang.com/">
              <Translate id="home.start.browser.cta">Open the IDE</Translate>
            </Link>
          </article>
          <article className={styles.stepCard}>
            <span className={styles.stepNumber}>02</span>
            <h3>
              <Translate id="home.start.install.title">Install for your system</Translate>
            </h3>
            <p>
              <Translate id="home.start.install.body">
                Grab the portable build for Windows, macOS, Linux, ARM, or
                FreeBSD. Unzip it, run it, and keep it on a thumb drive if you
                like.
              </Translate>
            </p>
            <Link className={styles.cardLink} to="/download">
              <Translate id="home.start.install.cta">Choose a download</Translate>
            </Link>
          </article>
          <article className={styles.stepCard}>
            <span className={styles.stepNumber}>03</span>
            <h3>
              <Translate id="home.start.docs.title">Write your first program</Translate>
            </h3>
            <p>
              <Translate id="home.start.docs.body">
                The quickstart takes you from an empty file to a running program
                in a few minutes, then points at the language guide.
              </Translate>
            </p>
            <Link className={styles.cardLink} to="/docs/quickstart">
              <Translate id="home.start.docs.cta">Read the quickstart</Translate>
            </Link>
          </article>
        </div>
      </div>
    </section>
  );
}

function Examples() {
  return (
    <section className={styles.examplesSection} id="examples">
      <div className={clsx('container', styles.exampleGrid)}>
        <div className={styles.exampleCopy}>
          <h2 className={styles.sectionTitle}>
            <Translate id="home.examples.title">A language you can read</Translate>
          </h2>
          <p className={styles.sectionLead}>
            <Translate id="home.examples.body">
              Familiar assignments, braces instead of indentation, and native
              parallel subroutines with the &lt;=&gt; operator. Skim the examples
              here, then run them without leaving the browser.
            </Translate>
          </p>
          <div className={styles.exampleLinks}>
            <Link className={styles.cardLink} to="/examples">
              <Translate id="home.examples.more">More examples</Translate>
            </Link>
            <Link className={styles.cardLink} to="/docs/fundamentals">
              <Translate id="home.examples.guide">Language guide</Translate>
            </Link>
          </div>
        </div>
        <div className={styles.exampleCode}>
          <CodeExamples />
        </div>
      </div>
    </section>
  );
}

function Handheld() {
  return (
    <section className={styles.handheldSection} id="handheld">
      <div className={clsx('container', styles.handheldInner)}>
        <div className={styles.handheldCopy}>
          <p className={styles.eyebrow}>
            <Translate id="home.handheld.eyebrow">JukaHub on the handheld</Translate>
          </p>
          <h2 className={styles.sectionTitle}>
            <Translate id="home.handheld.title">Link-cable games, over Wi-Fi.</Translate>
          </h2>
          <p className={styles.sectionLead}>
            <Translate id="home.handheld.body">
              JukaHub already browses the games on your card and launches each one
              with the emulator that owns its console. Now two handhelds on the
              same Wi-Fi can play the link-cable titles together — Mario Kart,
              Zelda Four Swords, and the rest of the Game Boy, Game Boy Advance,
              SNES and Mega Drive library — with no cable and no account.
            </Translate>
          </p>
          <ul className={styles.handheldList}>
            <li>
              <strong>Host or join from the library.</strong> Press X on a game:
              the host prints its own address before launching, and the other
              player types that address once.
            </li>
            <li>
              <strong>Both sides run the same core and ROM.</strong> The session
              starts only when RetroArch and a netplay-capable core are installed,
              and it says exactly what is missing when they are not.
            </li>
            <li>
              <strong>Nothing to configure.</strong> The port and nickname are
              passed on the command line, so your RetroArch config is never edited
              and nothing is announced publicly.
            </li>
          </ul>
          <div className={styles.exampleLinks}>
            <Link className={styles.primaryCta} to="/download">
              <Translate id="home.handheld.cta">Get JukaHub</Translate>
            </Link>
            <Link className={styles.tertiaryCta} to="/changelog">
              <Translate id="home.handheld.changelog">See what shipped →</Translate>
            </Link>
          </div>
        </div>
        <figure className={styles.handheldShot}>
          <img
            src="/img/lanplay.png"
            alt="The JukaHub LAN Play panel: host this game or join a game, with the device's own address shown as 192.168.68.59:55435"
            loading="lazy"
          />
          <figcaption>
            <Translate id="home.handheld.caption">
              LAN Play on the TrimUI Smart Pro: host the game, then join from the
              other device with the address on screen.
            </Translate>
          </figcaption>
        </figure>
      </div>
    </section>
  );
}

function CommunityBand() {
  return (
    <section className={styles.communitySection}>
      <div className={clsx('container', styles.communityInner)}>
        <div>
          <h2 className={styles.sectionTitle}>
            <Translate id="home.community.title">Built in the open</Translate>
          </h2>
          <p className={styles.sectionLead}>
            <Translate id="home.community.body">
              Juka is community-driven: the compiler, the docs, and the packages
              are all on GitHub. Ask questions, report what breaks, or help make
              the next release better.
            </Translate>
          </p>
          <div className={styles.exampleLinks}>
            <Link className={styles.primaryCta} to="/community">
              <Translate id="home.community.cta">Meet the community</Translate>
            </Link>
            <a
              className={styles.tertiaryCta}
              href="https://github.com/jukaLang/JukaHubV2"
              rel="noopener noreferrer">
              <Translate id="home.community.github">Contribute on GitHub →</Translate>
            </a>
          </div>
        </div>
        <HomepageSocial />
      </div>
    </section>
  );
}

export default function Home() {
  const {siteConfig} = useDocusaurusContext();
  return (
    <Layout
      title="Juka — a portable programming language"
      description="Juka is a portable, easy-to-learn programming language with native multithreading, a package manager and Web2/Web3 targets. Try it online or download it for Windows, macOS, Linux, ARM, FreeBSD and Android.">
      <Head>
        <link rel="canonical" href="https://jukalang.com/" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Juka — one language, every device" />
        <meta
          property="og:description"
          content="A portable, easy-to-learn programming language for beginners, makers and cross-platform builders."
        />
        <meta property="og:url" content="https://jukalang.com/" />
        <script type="application/ld+json">
          {JSON.stringify(softwareSchema)}
        </script>
      </Head>
      <HomepageHeader />
      <main>
        <StartSteps />
        <Examples />
        <Handheld />
        <HomepageFeatures />
        <CommunityBand />
        <div className="container">
          <QandA />
          <p className={styles.smallPrint}>
            <Link to="/quiz">
              <Translate id="home.quiz">Take the Juka quiz for a certificate</Translate>
            </Link>
            {' · '}
            <Link to="/donate">
              <Translate id="home.donate">Support the project</Translate>
            </Link>
          </p>
        </div>
      </main>
    </Layout>
  );
}
