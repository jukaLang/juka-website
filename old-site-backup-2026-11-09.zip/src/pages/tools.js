import React from 'react';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';
import styles from './infoPages.module.css';

const tools = [
  {
    title: 'Online IDE',
    description:
      'Write, run and share Juka in a browser tab. Works on phones and tablets, and installs as a home-screen app.',
    href: 'https://ide.jukalang.com/',
    cta: 'Open the IDE',
    primary: true,
  },
  {
    title: 'GUI Builder for JukaHub',
    description:
      'Design a handheld interface on a PC, preview it at the target resolution, and push it to a TrimUI device over Wi-Fi.',
    href: 'https://generate.jukalang.com',
    cta: 'Launch the builder',
  },
  {
    title: 'JukaOS',
    description:
      'The Juka operating-system image and its documentation, for devices and virtual machines.',
    href: 'https://os.jukalang.com/',
    cta: 'Visit JukaOS',
  },
  {
    title: 'JukaAPI',
    description:
      'Send Juka code to a REST endpoint and get the result back. Useful for bots, serverless functions and small services.',
    href: 'https://api.jukalang.com',
    cta: 'Explore the API',
  },
  {
    title: 'Package registry',
    description:
      'Community packages and their manifests, hosted on GitHub so anyone can audit, install or improve them.',
    href: 'https://github.com/jukaLang/Packages',
    cta: 'Browse packages',
  },
  {
    title: 'Jupyter kernel',
    description:
      'Run Juka cells inside Jupyter Notebook and Lab, alongside the analysis tools you already use.',
    href: 'https://pypi.org/project/juka-kernel/',
    cta: 'Install the kernel',
  },
];

export default function Tools() {
  return (
    <Layout
      title="Juka tools"
      description="The Juka online IDE, the JukaHub GUI builder, JukaOS, JukaAPI, the package registry and the Jupyter kernel.">
      <main className={styles.page}>
        <div className="container">
          <header className={styles.hero}>
            <p className={styles.eyebrow}>Tools</p>
            <h1 className={styles.title}>Everything around the language</h1>
            <p className={styles.lead}>
              The GUI builder is one companion tool, not the front door. Here is
              the full set: write and run Juka, design a handheld interface, call
              it over HTTP, or use it from a notebook.
            </p>
            <div className={styles.linkRow}>
              <Link className={styles.button} to="/docs/quickstart">
                Start with the language
              </Link>
              <Link className={styles.textLink} to="/download">
                Download Juka →
              </Link>
            </div>
          </header>

          <div className={styles.grid}>
            {tools.map((tool) => (
              <article
                key={tool.title}
                className={
                  tool.primary
                    ? `${styles.card} ${styles.cardPrimary}`
                    : styles.card
                }>
                <h2>{tool.title}</h2>
                <p>{tool.description}</p>
                <a
                  className={styles.cardLink}
                  href={tool.href}
                  rel="noopener noreferrer">
                  {tool.cta} →
                </a>
              </article>
            ))}
          </div>

          <p className={styles.note}>
            Looking for the TrimUI handheld app itself? The builder produces its
            layout file, but the app lives in{' '}
            <a href="https://github.com/jukaLang/JukaHubV2">JukaHubV2</a> and is
            installed from the SD-card release.
          </p>
        </div>
      </main>
    </Layout>
  );
}
