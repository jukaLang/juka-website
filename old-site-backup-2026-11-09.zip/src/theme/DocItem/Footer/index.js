import React from 'react';
import Footer from '@theme-original/DocItem/Footer';
import {useDoc} from '@docusaurus/plugin-content-docs/client';
import styles from './styles.module.css';

// Docs feedback without a backend: the report opens as a prefilled GitHub
// issue on the public repository, so replies, triage and history stay in the
// open instead of disappearing into an inbox.
export default function FooterWrapper(props) {
  const {metadata} = useDoc();
  const permalink = `https://jukalang.com${metadata.permalink}`;
  const title = encodeURIComponent(`Docs feedback: ${metadata.title}`);
  const body = encodeURIComponent(
    `Page: ${metadata.title}\nURL: ${permalink}\n\nWhat is wrong or unclear?\n\n`,
  );
  const issueUrl = `https://github.com/jukaLang/JukaHubV2/issues/new?title=${title}&body=${body}&labels=documentation`;

  return (
    <>
      <Footer {...props} />
      <aside className={styles.feedback} aria-label="Documentation feedback">
        <p className={styles.question}>Was this page helpful?</p>
        <p className={styles.detail}>
          Found a mistake or something missing?{' '}
          <a href={issueUrl} target="_blank" rel="noopener noreferrer">
            Report it on GitHub
          </a>{' '}
          — the page URL is prefilled for you.
        </p>
      </aside>
    </>
  );
}
